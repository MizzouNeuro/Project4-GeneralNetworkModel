Spike_Data = dlmread('results/testrun/spikeraster.dat')
figure
plot(Spike_Data(:,1),Spike_Data(:,2),'.')