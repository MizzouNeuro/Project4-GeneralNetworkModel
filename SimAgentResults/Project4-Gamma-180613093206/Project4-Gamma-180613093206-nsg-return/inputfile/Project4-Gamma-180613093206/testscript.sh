rm *.c
rm *.o
rm *.dll
export PYTHONHOME=/cygdrive/c/nrn73
export PYTHONPATH=/cygdrive/c/nrn73/lib
export N=/cygdrive/c/nrn73
export NEURONHOME=/cygdrive/c/nrn73
export PATH="/cygdrive/c/nrn73/bin:$PATH"
mknrndll
export PYTHONHOME=/cygdrive/c/Python34
export PYTHONPATH=/cygdrive/c/Python34/Lib/



